// 1 задание начало

let name = prompt("ваше имя?");
alert(name);

// 1 задание конец