// 1 задание начало

/* let name = prompt("ваше имя?");
alert(name); */

// 1 задание конец



// 2 задание начало

// let number = 10;

// nextPrime:
// for (let i = 2; i <= number; i++) { // Для всех i...

//    for (let check = 2; check < i; check++) { 
//       if (i % check == 0) continue nextPrime; 
//    }

//    console.log(i);
// }

// 2 задание конец



// 3 задание начало

// let i = 11

// while (i <= 33) {

//    i++
//    console.log(i - 1)

// }

// console.log("==================================")

// for (let i = 11; i <= 33; i++) {

//    console.log(i)

// }

// console.log("==================================")

// let k = 0;

// while (k <= 100) {

//    console.log(k)
//    k += 2

// }

// console.log("==================================")

// for (let i = 0; i <= 100; i++) {

//    if (i % 2 == 0) {
//       console.log(i)
//    }

// }

// 3 задание конец



// 4 задание начало

const season = +prompt("Бір сан таңдаңыз: 1, 2, 3, 4")

switch (season) {

   case 1:
      alert("қыс")
      break;

   case 2:
      alert("көктем")
      break;

   case 3:
      alert("жаз")
      break;

   case 4:
      alert("күз")
      break;

   default:
      alert("Ондай сан жоқ");

}


// 4 задание конец